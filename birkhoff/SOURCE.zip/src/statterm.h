#ifndef STATTERM_H
#define STATTERM_H 1

/*
  this is used by the integration code to evaluate different integration
  strategies
  
  it is a friend of the term class

  it is separated out so the arrays are just allocated once.

  before use: define an object S of type statterm and call S.setup()
*/

class statterm {
private:
    int N;
    class evaldata {
    public:
	int start;
	int mult;
	bool int_ok;
	bool ext_ok;
	int int_eval;
	int ext_eval;
    };
private:
    int nvar;
    CZI * IK;
    int * KV;
    int ** Q;
    int * NZZ;
    int * DZZ;
    int nblock;
    evaldata * E;
    bool Factoring;
    bool TopCoefficient;
    bool ZeroCheck;
public:
    int besteval;
    char bestdir;
    int bestmult;
    CZI bestz;
    int zeroz;
public:
    void evaluate(const term& t);
    void setup(int n, bool factoring, bool topcoefficient, bool zerocheck);
    bool ok_int(int v, char d, int m, CZI& qz);
    friend ostream& operator<<(ostream& f, const statterm& S);
    ostream& dumpeval(ostream& f) const;
};

#endif
