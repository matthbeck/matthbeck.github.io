#ifndef CALC_H
#define CALC_H 1

#include <assert.h>

/*
  This class supplies factorials, binomials and related calculations.
  It precalculates a range of values; if the pre-calculated range is
  sufficient then use the functions which do not have INT arguments;
  they simply return a reference to the precalculated value.

  There is one object C of class calc, so all calls go through it.
*/

class calc {
public:
    ctr maxnmc_r;
    ctr maxnmc_m;
    ctr maxnmcval;

public:
    calc() {}
    ~calc();
    INT& Factorial(INT & result, int n);
    const INT& Factorial(int n) {
	 assert(0<=n && n<=MAXvFact);
	 return vFactorial[n];
    }
    INT& Ibin(INT& result, int n, int k);
    const INT& Ibin (int n, int k) {
	 assert(0<=k && k<=n && n<=MAXvIbin);
	 return vIbin[n][k];
    }

// number of muultinomial coefficients [r:k1 k2 ... km ]
// this is just the binomial coefficient [r+m-1 : m-1], but we calculate it
// directly
    uint nmc(int r, int m) {
	assert(r>=0 && m>=0);
	uint result;
	if (r <= MAXvnmc_r && m < MAXvnmc_m)
	    result = vnmc[r][m];
	else
	    result = calcnmc(r,m);
	maxnmc_r.max(r);
	maxnmc_m.max(m);
	maxnmcval.max(result);
	return result;
    }

// number of muultinomial coefficients [t:k1 k2 ... km ] restricted so 
// k1 <= p
    uint nmc(int r, int m, int p);
	
// the MAX values are determined from N and TopDeg if not specified
// in this default setting factorials and binomial coefficients are 
// precalculated for parameters from 0 to TopDeg, and nmc values are
// calculated for r (the degree of the multinomial) up to TopDeg and 
// m (the number of terms) up to N-1

    void precalc(int N, int TopDeg,
		    int MAXvFact1 = 0, int MAXvIbin1 = 0, 
		    int MAXvnmc_r1 = 0, int MAXvnmc_m1 = 0);

private:
    int MAXvFact;
    int MAXvIbin;
    int MAXvnmc_m;
    int MAXvnmc_r;

    INT* vFactorial;
    INT** vIbin;
    uint** vnmc;

    uint ibin(int n, int k);
    uint factorial(int n);
    uint calcnmc(int r, int m);
};

extern calc C;

#endif
