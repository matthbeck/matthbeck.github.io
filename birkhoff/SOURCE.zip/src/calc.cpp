using namespace std;
#include "bignum.h"
#include "count.h"
#include "calc.h"

calc::~calc() {
    if(vFactorial)
	delete[] vFactorial;
    if(vIbin) {
	for(int n=0; n<= MAXvIbin; n++)
	    delete[] vIbin[n];
	delete[] vIbin;
    }
    if(vnmc) {
	for(int r=0; r<= MAXvnmc_r; r++)
	    delete[] vnmc[r];
	delete[] vnmc;
    }
}

// no bounds checking here
uint calc::factorial(int n) {
    if (n == 0)
	return 1;
    else
	return  n*factorial(n-1);
}

INT& calc::Factorial(INT& result, int n) {
    if (n <= MAXvFact && vFactorial[n] != 0) {
	return result = vFactorial[n];
    }
    if (n <= 12) {
	return result = factorial(n);
    }
    Factorial(result,n-1);
    return result *= n;
}

// no bounds checking here
uint calc::ibin(int n, int k) {
    if (n-k<k)
  	return ibin(n,n-k);
    if (k == 0)
	return 1;
    return ibin(n-1,k-1)*n/k;
}
    
INT& calc::Ibin(INT& result, int n, int k) {
    assert(0<=k && k<=n);
    if (n <= MAXvIbin && vIbin[n][k] != 0) {
	result = vIbin[n][k];
	return result;
    }
    if (n-k<k)
	return Ibin(result,n,n-k);
    if (k == 0)
	return result = 1;
    if (n<=30)
	return result = ibin(n,k);
    Ibin(result,n-1,k-1);
    result *= n;
    result /= k;
    return result;
}

uint calc::calcnmc(int r, int m) {
    assert(r>=0 && m>=0);
    if (r <= MAXvnmc_r && m <= MAXvnmc_m && vnmc[r][m] > 0)
	return vnmc[r][m];
    uint tot;
    if (r == 0)
	tot = 1;
    else if (m == 0)
	tot = 0;
    else if (m == 1)
	tot = 1;
    else {
	tot = 0;
	for (int q = 0; q <= r; q++)
	    tot += calcnmc(q,m-1);
    }
    return tot;
}

uint calc::nmc(int r, int m, int p) {
    assert(r>=0 && m>=0 && p>=0);
    if (r <= p)
	return nmc(r,m);
    uint tot = 0;
    for (int q = r-p; q <= r; q++)
	tot += nmc(q,m-1);
    maxnmc_r.max(r);
    maxnmc_m.max(m);
    maxnmcval.max(tot);
    return tot;
}

void calc::precalc (int N, int TopDeg,
		    int MAXvFact1, int MAXvIbin1, 
		    int MAXvnmc_r1, int MAXvnmc_m1) {

    MAXvFact = MAXvFact1;
    if(MAXvFact<=0)
	MAXvFact = TopDeg;
    MAXvIbin = MAXvIbin1;
    if(MAXvIbin<=0)
	MAXvIbin = TopDeg;
    MAXvnmc_r = MAXvnmc_r1;
    if(MAXvnmc_r<=0)
	MAXvnmc_r = TopDeg;
    MAXvnmc_m = MAXvnmc_m1;
    if(MAXvnmc_m<=0)
	MAXvnmc_m = N-1;

    vFactorial = new INT[MAXvFact+1];
    for(int n=0;n<=MAXvFact;n++)
	Factorial(vFactorial[n],n);

    vIbin = new INT*[MAXvIbin+1];
    for(int n=0;n<=MAXvIbin;n++)
	vIbin[n] = new INT[MAXvIbin+1];
    for(int n=0;n<=MAXvIbin;n++)
	for(int k=0;k<=n;k++)
	    Ibin(vIbin[n][k],n,k);

    vnmc = new uint*[MAXvnmc_r+1];
    for(int r=0;r<=MAXvnmc_r;r++)
	vnmc[r] = new uint[MAXvnmc_m+1];
    for(int r=0;r<=MAXvnmc_r;r++)
	for(int m=0; m<=MAXvnmc_m; m++) {
	    vnmc[r][m] = 0;
	    vnmc[r][m] = calcnmc(r,m);
	}
}

calc C;
