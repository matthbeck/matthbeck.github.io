#include <iostream>

// reads at least one character; returns the first whitespace character,
// or '\n' or EOF

int skipspace(istream& f);

// reads until EOF or '\n', and returns it

int skiptoeol(istream& f);

// for the M_QUERY interaction

bool parseline(istream& f, int& qvar, char& qdir, int& qmult, char& errch);
