#ifndef BIGNUM_H
#define BIGNUM_H 1

/*
  just the gmp classes, plus some simple extensions
  the idea is to keep the core gmp code here (the parts of the gmp
  package that are not currently handled by the C++ wrapper)
*/

// strstream is required by gmpxx.h
#include <sstream>
#include <gmpxx.h>

typedef mpz_class INT;
typedef mpq_class RAT;

INT& operator^=(INT& v, int p);
RAT& operator^=(RAT& v, int p);

RAT& fraction(RAT& V, const INT& N, const INT& D);

INT& gcd(INT& result, const INT& X, const INT& Y);
INT& lcm(INT& result, const INT& X, const INT& Y);

#endif
