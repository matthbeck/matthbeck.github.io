using namespace std;
#include <getopt.h>
#include "bignum.h"
#include "count.h"
#include "calc.h"
#include "poly.h"

int errmsg(char * mess) {
    cerr << "Error: " << mess << "\n";
    return 2;
}

int usage(char * prog) {
    cerr << "usage: " << prog << " -d deg [ -e range ]" << "\n";
    return 1;
}

int main(int argc, char ** argv) {
    int deg = -1;
    char* eval_range = 0;
    int eval_start = 1;
    int eval_end = 0;
    int c;

    while ((c = getopt(argc,argv,"d:e:")) >= 0)
	switch(c) {
	case 'd': deg = atoi(optarg); break;
	case 'e': eval_range = optarg; break;
	default:
	    return usage(argv[0]);
	}

    if(deg < 0)
	return usage(argv[0]);

    if (eval_range) {
	eval_start = atoi(eval_range);
	for(;*eval_range && *eval_range!=':'; eval_range++);
	if (*eval_range!=':')
	    return errmsg("evaluation range must be in the form start:stop");
	eval_end = atoi(eval_range+1);
    }

    poly T(deg);
    poly P(deg);

    while (cin >> T) {
//  	cout << "=== " << T << "\n";
	P += T;
    }
    cout << "\nSum =\n" << P << "\n\n";

    if (eval_range) {
	RAT v;
	for(int k=eval_start; k<=eval_end; k++)
	cout << "    P(" << k << ") = " << P.eval(v,k) << "\n";
    }
}
