#ifndef UPOLY_H
#define UPOLY_H 1

#include <map>

/*
  this provides a polynomial cache (holding intermediate results that occur 
  as bfactor::tpoly()) 
  and a small number of scratch polynomials (again to avoid excess mallocs
  during evaluation of tpoly's.
  
  before use: define an object U of type upoly and call U.initialize()

  The cache entries are keyed by an unsigned int; the actual value of the
  key is unused.
*/

class upoly {
private:
    class cache_poly {
    public:
	poly cp;
	cache_poly() :cp(0) {}
    };
    typedef map <uint,cache_poly> cache_map;
    typedef cache_map::iterator CMI;
    typedef cache_map::const_iterator CCMI;
    cache_map CM;
    int nscratch;
    vector<poly> Q;
public:
    static ctr numsetcache;
    static CTR numgetcache;
public:
    upoly() :Q(0) {}
    ~upoly() {}
    void initialize(int topdeg, int nscratch1) {
	nscratch = nscratch1;
	Q.resize(nscratch);
	for(int k=0; k<nscratch; k++)
	    Q[k].set_maxdeg(topdeg);
    }
    const poly& get_cache_poly(uint key) {
	numgetcache++;
//	cerr << "get_cache " << hex << key << dec << " -> " << CM[key].cp << "\n";
	return CM[key].cp;
    }
    const poly& set_cache_poly(uint key, const poly& P) {
	numsetcache++;
	cache_poly& c = CM[key];
	c.cp.set_maxdeg(P.deg());
	c.cp = P;
//	cerr << "set_cache " << hex << key << dec << " -> " << CM[key].cp << "\n";
	return c.cp;
    }
    poly& scratch(int k) {
	Q[k] = 0;
	return Q[k];
    }
};

#endif
