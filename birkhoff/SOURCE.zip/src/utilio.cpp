using namespace std;
#include "utilio.h"
#include <cctype>

int skipspace(istream& f) {
    int c;
    while (true) {
	c = f.get();
	if (c == EOF || c == '\n' || !isspace(c))
	    return c;
    }
}

int skiptoeol(istream& f) {
    int c;
    while (true) {
	c = f.get();
	if (c == EOF || c == '\n')
	    return c;
    }
}


// returns false if eof
bool parseline(istream& f, int& qvar, char& qdir, int& qmult, char& errch) {
    int c;
    qvar = 0;
    qdir = 0;
    qmult = 0;
    errch = 0;
    while(true) {
	switch(c = skipspace(f)) {
	case EOF:
	    return false;
	case '\n':
	    return true;
	case 'e':
	case 'i':
	    if(qvar)
		qdir = (char)c;
	    break;
	default:
	    if(isdigit(c)) {
		if(!qvar) {
		    f.unget();
		    f >> qvar;
		    break;
		}
		else if(!qmult) {
		    f.unget();
		    f >> qmult;
		    break;
		}
	    }
	    errch = (char)c;
	    return skiptoeol(f) != EOF;
	}
    }
}

