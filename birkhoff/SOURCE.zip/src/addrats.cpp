using namespace std;
/*
  just adds RATS on cin
*/

#include "bignum.h"

int main() {
    RAT sum,term;
    while (cin>>term) {
	term.canonicalize();
	sum += term;
    }
    cout << sum << "\n";
}
