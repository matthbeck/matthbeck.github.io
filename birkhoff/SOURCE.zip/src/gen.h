#ifndef GEN_H
#define GEN_H 1

#include <vector>
#include <assert.h>

class generator {
public:
    virtual ~generator() {}
    virtual bool empty() const = 0;
    virtual term& generate(term& t) = 0;
};

class expgen :public generator {
private:
    expr e;
public:
    bool empty() const {return e.empty();}
    term& generate(term& t) {
	assert(!empty());
	e.getfirst(t);
	return t;
    }
    void initialize(expr& E) {
	e = 0;
	e.addfirst(E);
    }
};    

class powgen :public generator {
private:
    class factor_record {
    public:
	int D;
	int M;
	term t;
	term T;
    };
private:
    int q;
    int n;
    term F0;
    vector<factor_record> F;
    bool Empty;
public:
    powgen() :F(0) {q = 0; F0 = 1; Empty = true;}
    bool empty() const {return Empty;}
    void initialize(term& f, expr& E, int pow);
    term& generate(term &t);
private:
    void INC(int k);
};

class prodgen :public generator {
private:
    class factor_record {
    public:
	int j;
	int numt;
	bool last;
	vector<term> t;
    };
private:
    int n;
    vector<factor_record> F;
    bool Empty;
public:
    prodgen() :F(0) {n = 0; Empty = true;}
    bool empty() const {return Empty;}
    void initialize(vector<expr>& E);
    term& generate(term &t);
private:
    void INC(int k);
};



#endif
