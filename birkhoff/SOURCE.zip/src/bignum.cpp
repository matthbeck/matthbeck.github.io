using namespace std;
#include "bignum.h"

INT& operator^=(INT& v, int p) {
    assert(p>=0);
    mpz_pow_ui(v.get_mpz_t(),v.get_mpz_t(),p);
    return v;
}

RAT& fraction(RAT& v, const INT& N, const INT& D) {
    v.get_num() = N;
    v.get_den() = D;
    v.canonicalize();
    return v;
}

RAT& operator^=(RAT& v, int p) {
    if (p>=0) {
	mpz_pow_ui(v.get_num_mpz_t(),v.get_num_mpz_t(),p);
	mpz_pow_ui(v.get_den_mpz_t(),v.get_den_mpz_t(),p);
	return v;
    }
    else {
	mpq_inv(v.get_mpq_t(),v.get_mpq_t());
	return v ^= -p;
    }
}

INT& gcd(INT& result, const INT& X, const INT& Y) {
    mpz_gcd (result.get_mpz_t(), X.get_mpz_t(), Y.get_mpz_t());
    return result;
}

INT& lcm(INT& result, const INT& X, const INT& Y) {
    mpz_lcm (result.get_mpz_t(), X.get_mpz_t(), Y.get_mpz_t());
    return result;
}
