#ifndef COUNT_H
#define COUNT_H 1

#include <sys/types.h>
#include <iostream>

/*
  This handles statistics (counts and max values)
  which (optionally) may become larger than UINT_MAX.
  Presumably the tests for BIG will be optimized away by the compiler.
*/

template<class NUM, bool BIG> class _ctr {
private:
    uint tot;  // only used in the BIG case
    NUM  TOT;
    enum { COUNTLIM = 1000000000 };
public:
    _ctr() {tot = 0; TOT = 0;}
    _ctr<NUM,BIG>& operator++() {
	if(BIG) {
	    ++tot;
	    if (tot >= COUNTLIM) {
		TOT += tot;
		tot = 0;
	    }
	}
	else
	    ++TOT;
	return *this;
    }
    _ctr<NUM,BIG>& operator++(int) {
	return ++*this;
    }
    _ctr<NUM,BIG>& max(const NUM& val) {
	if (BIG && tot) {
	    TOT += tot;
	    tot = 0;
	}
	if (val > TOT)
	    TOT = val;
	return *this;
    }
    _ctr<NUM,BIG>& maxabs(const NUM& val) {
	if (val > 0)
	    max(val);
	else
	    max(-val);
	return *this;
    }
    friend ostream& operator<< <>(ostream& f, const _ctr<NUM,BIG>& v);
};

template<class NUM, bool BIG>
ostream& operator<< (ostream& f, const _ctr<NUM,BIG>& v) {
    NUM TMP;
    TMP = v.TOT;
    if(BIG) 
	TMP += v.tot;
    return f << TMP;
}

typedef _ctr<int,false> ctr;

#ifdef BIGNUM_H
typedef _ctr<INT,true> CTR;
#endif

#endif
